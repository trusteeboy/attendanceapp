package com.example.computer;

public class ClassItem
{

    private long    cid;
   private String className;
   private String Semester;

    public ClassItem(long cid, String className, String semester) {
        this.cid = cid;
        this.className = className;
        this.Semester = semester;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getSemester() {
        return Semester;
    }

    public void setSemester(String semester) {
        Semester = semester;
    }

    public ClassItem(String className, String semester) {
        this.className = className;
        Semester = semester;
    }

    public long getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }
}
