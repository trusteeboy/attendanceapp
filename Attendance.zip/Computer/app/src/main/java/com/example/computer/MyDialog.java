package com.example.computer;

import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class MyDialog extends DialogFragment {
    public static final String CLASS_ADD_DIALOG="addClass";
    public static final String CLASS_UPDATE_DIALOG="updateClass";
    public static final String STUDENT_ADD_DIALOG="addStudent";
    public static final String STUDENT_UPDATE_DIALOG = "updateStudent" ;

    private OnClickListner listner ;
    private int roll;
    private String name;

    public MyDialog(int roll, String name) {

        this.roll = roll;
        this.name = name;
    }

    public MyDialog() {

    }

    public interface OnClickListner
    {
        void onClick(String text1,String text2);
    }

    public void setListner(OnClickListner listner) {
        this.listner = listner;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        
        Dialog dialog=null;
        if (getTag().equals(CLASS_ADD_DIALOG))dialog=getAddClassDialog();
        if (getTag().equals(STUDENT_ADD_DIALOG))dialog=getAddStudentDialog();
        if (getTag().equals(CLASS_UPDATE_DIALOG))dialog=getupdateClassDialog();
        if (getTag().equals(STUDENT_UPDATE_DIALOG))dialog=getUpdateStudentDialog();


        return dialog;
    }

    private Dialog getUpdateStudentDialog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view   = LayoutInflater.from(getActivity()).inflate(R.layout.dialog,null);
        builder.setView(view);

        TextView title = view.findViewById(R.id.titleDialog);
        title.setText("UPDATE Student");

        EditText roll_edt = view.findViewById(R.id.edt01);
        EditText name_edt = view.findViewById(R.id.edt02);

        roll_edt.setHint("Student Roll");
        name_edt.setHint("Student Name");
        Button cancel = view.findViewById(R.id.cancel_btn);
        Button add = view.findViewById(R.id.add_btn);
        add.setText("UPDATE");
        roll_edt.setText(roll+"");
        name_edt.setText(name);
        roll_edt.setEnabled(false);
        cancel.setOnClickListener(v-> dismiss());
        add.setOnClickListener(v->
        {
            String roll= roll_edt.getText().toString();
            String name= name_edt.getText().toString();

            listner.onClick(roll,name);
            dismiss();
        });
        return builder.create();

    }

    private Dialog getupdateClassDialog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view   = LayoutInflater.from(getActivity()).inflate(R.layout.dialog,null);
        builder.setView(view);

        TextView title = view.findViewById(R.id.titleDialog);
        title.setText("UPDATE Class");

        EditText class_id_edt = view.findViewById(R.id.edt01);
        EditText sem_id_edt = view.findViewById(R.id.edt02);

        class_id_edt.setHint("Subject Name");
        sem_id_edt.setHint("Semester");
        Button cancel = view.findViewById(R.id.cancel_btn);
        Button add = view.findViewById(R.id.add_btn);
        add.setText("UPDATE");

        cancel.setOnClickListener(v-> dismiss());
        add.setOnClickListener(v->
        {
            String className= class_id_edt.getText().toString();
            String semester= sem_id_edt.getText().toString();
            listner.onClick(className,semester);
            dismiss();
        });
        return builder.create();


    }

    private Dialog getAddStudentDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view   = LayoutInflater.from(getActivity()).inflate(R.layout.dialog,null);
        builder.setView(view);

        TextView title = view.findViewById(R.id.titleDialog);
        title.setText("Add New Student");

        EditText roll_edt = view.findViewById(R.id.edt01);
        EditText name_edt = view.findViewById(R.id.edt02);

        roll_edt.setHint("Student Roll");
        name_edt.setHint("Student Name");
        Button cancel = view.findViewById(R.id.cancel_btn);
        Button add = view.findViewById(R.id.add_btn);

        cancel.setOnClickListener(v-> dismiss());
        add.setOnClickListener(v->
        {
            String roll= roll_edt.getText().toString();
            String name= name_edt.getText().toString();
            roll_edt.setText(String.valueOf(Integer.parseInt(roll)+1));
            name_edt.setText("");
            listner.onClick(roll,name);
        });
        return builder.create();

    }

    private Dialog getAddClassDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view   = LayoutInflater.from(getActivity()).inflate(R.layout.dialog,null);
        builder.setView(view);

        TextView title = view.findViewById(R.id.titleDialog);
        title.setText("Add New Class");

        EditText class_id_edt = view.findViewById(R.id.edt01);
        EditText sem_id_edt = view.findViewById(R.id.edt02);

        class_id_edt.setHint("Subject Name");
        sem_id_edt.setHint("Semester");
        Button cancel = view.findViewById(R.id.cancel_btn);
        Button add = view.findViewById(R.id.add_btn);

        cancel.setOnClickListener(v-> dismiss());
        add.setOnClickListener(v->
        {
            String className= class_id_edt.getText().toString();
            String semester= sem_id_edt.getText().toString();
            listner.onClick(className,semester);
            dismiss();
        });
       return builder.create();
    }
}
